<?php
session_start();
include('database.php');

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']); // Escape user input
    $password = mysqli_real_escape_string($conn, $_POST['password']); // Escape user input

    if (empty($email) || empty($password)) {
        // Check if email or password is empty
        $_SESSION['status'] = "<span style='color: red;'>All fields are required.</span>";
        header("Location: login.php");
        exit();
    }

    $login_query = "SELECT * FROM user WHERE email= ? LIMIT 1";
    $stmt = mysqli_stmt_init($conn);

    if (mysqli_stmt_prepare($stmt, $login_query)) {
        // Prepare the SQL statement
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $login_query_run = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($login_query_run) > 0) {
            $row = mysqli_fetch_array($login_query_run);
            
            // Check if the user is verified
            if ($row['verify_status'] != "1") {
                $_SESSION['status'] = "<span style='color: red;'>Please verify your email address.</span>";
                header("Location: login.php");
                exit();
            }
            
            if (password_verify($password, $row['password'])) {
                // Password verification
                $_SESSION['full_name'] = $row['full_name'];
                $_SESSION['contact'] = $row['contact'];
                $_SESSION['email'] = $email;
                header("Location: user_dashboard.php");
                exit();
            } else {
                // Invalid password
                $_SESSION['status'] = "<span style='color: red;'>Invalid Email or Password.</span>";
                header("Location: login.php");
                exit();
            }
        } else {
            // Email not found
            $_SESSION['status'] = "<span style='color: red;'>Email not existing.</span>";
            header("Location: login.php");
            exit();
        }
    } else {
        // Handle the prepare statement error
        $_SESSION['status'] = "<span style='color: red;'>Database error.</span>";
        header("Location: login.php");
        exit();
    }
}
?>
