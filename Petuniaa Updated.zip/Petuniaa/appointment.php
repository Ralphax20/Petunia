<!doctype html> 
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="./images/icons8-dog-bone-32.png" type="image/x-icon">
  <title>Petunia</title>
  <link rel="stylesheet" href="./appointment.css">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.css" rel="stylesheet">
</head>
<body>
<!--Nav -->
  <nav class="navbar">
    <div class="navbar-container">
      <h2 class="Petunia"><a href="user_dashboard.php">Petunia</a></h2>
      <ul>
        <li><a href="user_dashboard.php" id="home-button">Home</a></li>
        <li><a href="user_dashboard.php" id="about-button">About</a></li>
        <li class="dropdown">
          <a href="">Services</a>
          <ul class="dropdown-content">
            <li><a href="" id="">Pet Groom</a></li>
          </ul>
        </li>
        <li><a href="necessities.php">Necessities</a></li>
      </ul>
      <div class="sign-in">
    <button><a href="logout.php">Sign out</a></button>
      </div>
    </div>
  </nav>
<!-- Main Content Full Calendar -->
<h2 class="text-center" style="margin-top: 30px; text-align: center;">Appointment Availability</h2>
<div class="container">
        <div id="calendar"></div>
    </div>
    <style>
    /* Custom CSS for resizing the calendar container */
    .container {
        width: 50%; /* Set the width as a percentage or in pixels */
        height: 600px; /* Set the height in pixels or any other unit */
        margin: 30px auto 0; /* Center the container horizontally */
    }
</style>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: [
                    {
                        title: 'Nothing',
                        start: '2023-10-20',
                        end: '2023-10-21'
                    },
                    {
                        title: 'Kantutan',
                        start: '2023-10-25',
                        end: '2023-10-27'
                    },
                    {
                        title: 'Nothing',
                        start: '2023-10-15',
                        end: '2023-10-16'
                    },
                    {
                        title: 'Halloween',
                        start: '2023-10-31',
                        end: '2023-10-1'
                    }
                    
                    // Add more events here
                ]
            });
            calendar.render();
        });
    </script>
    <style>
       .footer-bottom {
        text-align: center; /* Center-align text */
        background-color: #6daffe; /* Background color */
        color: black; /* Text color */
        border-top: 2px solid #000; /* Black top border */
        padding: 50px 0; /* Add padding for spacing */
    }
    </style>
    <div class="footer-bottom">
      <p>&copy; 2023 Petunia. All rights reserved.</p>
    </div>
</body>
</html>