<?php
session_start();
if (isset($_SESSION["user"])){
    header("Location: registration.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="shortcut icon" href="./asset-image/icons8-dog-bone-32.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    


<!-- Register Form -->
<div class="container" style="width: 420px;">
<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'vendor/autoload.php';
       
    function sendemail_verify($fullName,$email,$verify_token)
       {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->SMTPAuth = true;

        $mail->Host = "smtp.gmail.com";
        $mail->Username = "overdoseflyby@gmail.com";
        $mail->Password = "oteq njdm lgbz wpcy";

        $mail->SMTPSecure = "tls";
        $mail->Port = 587;

        $mail->setFrom("overdoseflyby@gmail.com", $fullName);
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = "Email Verification from Petunia";

        $email_template = "
            <h2> You have Registered with Petunia </h2>
            <h5> Verify your email address: <a href='http://localhost/htdocs/Petuniaa/verify.php?token=$verify_token'>Click Me</a></h5>
        ";

        $mail->Body = $email_template;
        $mail->send();
    }
    
    if (isset($_POST["submit"])) {
            $fullName = $_POST["fullname"];
            $contactnumber = $_POST["contact"];
            $username = $_POST["username"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $confirmpassword = $_POST["confirmpassword"];
            $verify_token = md5(rand());
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $errors = array();

            if (empty($fullName) OR empty($contactnumber) OR empty($username) OR empty($email) OR empty($password) OR empty($confirmpassword)){
                array_push($errors,"All fields are required");
            }

            if(!preg_match('/^[a-zA-Z\s]+$/', $fullName)){
                array_push($errors, "Numbers and Special Characters are not allowed in the full name");
                
            }
            if(!preg_match('/^[0-9]+$/', $contactnumber)){
                array_push($errors, "Letters are not allowed in the contact number or 
                Invalid contact number provided. It must start with '09' and be 10 digits long.");
            }
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            array_push($errors, "Email is not valid");
           }   
           if (strlen($password)<8){
            array_push($errors,"Password must be atleast 8 characters");
           }
           if ($password!==$confirmpassword){
            array_push($errors,"Password does not Match");
           }
           require_once "database.php";
           $sql = "SELECT * FROM user WHERE email = '$email'";
           $result = mysqli_query($conn, $sql);
           $rowCount = mysqli_num_rows($result);
           if ($rowCount>0) {
            array_push($errors,"Email Already Exists!");
           }
           if (count($errors)>0) {
            foreach($errors as $error) {
                echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
            $sql = "INSERT INTO user (full_name, email, password, contact, verify_token) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);
            $prepareStmt = mysqli_stmt_prepare($stmt, $sql);
            if ($prepareStmt) {
                sendemail_verify("$fullName","$email","$verify_token");
                mysqli_stmt_bind_param($stmt,"sssss",$fullName, $email, $passwordHash ,$contactnumber,$verify_token);
                mysqli_stmt_execute($stmt);
                echo "<div class='alert alert-success'>Check your email for verification.</div>";
    } else {
                die("Something went wrong");
            }
        }
    }
?>
        <form action="registration.php" method="post">
            <h1>Register</h1>
            <div class="form-group">
                <input type="text" class="form-control" name="fullname" id = "name" placeholder="Fullname" autocomplete="off">
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="contact" placeholder="Contact"  id="myInput" value="09" oninput="checkNumber(this)" autocomplete="off">
            </div>
            <div class="form-group">
                <input type="username" class="form-control" name="username" placeholder="Username" autocomplete="off">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary full-width" name="submit" value="Register">
            </div>
        </form>
        <div class="register">
                <p style="text-align: center; margin-top: 30px; font-size: 14px;">Already have an account? <a href="login.php" style="text-decoration: none; color:black;">Login</a></p>
        </div>
    </div>
    <!-- Register Form End -->   
</body>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const inputField = document.getElementById('myInput');
    
    inputField.addEventListener('input', function() {
      if (!inputField.value.startsWith('09')) {
        inputField.value = '09' + inputField.value.substring(2); // Ensure it always starts with "09"
      }
    });
  });
function checkNumber(input) {
    if (input.value.length > 11) {
        input.value = input.value.slice(0, 11);
    }
}
</script>
</html>