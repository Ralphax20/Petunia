document.addEventListener("DOMContentLoaded", function() {
    const aboutButton = document.getElementById("about-button");
    const aboutSection = document.getElementById("about-section");
    const homeButton = document.getElementById("home-button");
    const homeSection = document.getElementById("home-section");

    aboutButton.addEventListener("click", function(event){
        event.preventDefault();
        aboutSection.scrollIntoView({behavior: "smooth"});

    homeButton.addEventListener("click", function(event){
        event.preventDefault();
        homeSection.scrollIntoView({behavior: "smooth"});
    });

    });

});