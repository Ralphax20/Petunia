<?php

session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resend</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="shortcut icon" href="./asset-image/icons8-dog-bone-32.png" type="image/x-icon">
</head>
<body>
<style>
body {
    padding: 30px;
    background: url('./2JWXmj.jpg') no-repeat;
    box-sizing: border-box;
    min-height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    background-position: center;
    background-size: cover;
}
.container {
    max-width: 600px;
    margin: 0 auto;
    padding: 50px;
    box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
    background-color: whitesmoke;
    border-radius: 20px;
    overflow: hidden;
    z-index: 1;
}
.container h1 {
    text-align: center;
    margin-bottom: 30px;
    font-weight: 600px;
    position: relative;
}
.form-group{
    margin-bottom: 15px;
}
.full-width{
    width: 100%;
}
</style>
<div class="container" style="width: 420px;">
<?php
    if(isset($_SESSION['status'])){
    ?>
    <div class="alert alert-success">
        <?= $_SESSION['status']; ?>
    </div>
    <?php
    unset($_SESSION['status']); }
    ?>
<form action="resend-code.php" method="post">
    <h1 style="color: red; font-size: 20px">Resend Email Verification</h1>
<div class="form-group">
            <input type="email" placeholder="Enter your email address." name="email" class="form-control" autocomplete="off">
</div>
<div class="form-btn">
            <input type="submit" value="Resend" name="resend" class="btn btn-primary full-width">
</div>
</form>
</div>
</body>
</html>