<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="shortcut icon" href="./asset-image/icons8-dog-bone-32.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container" style="width: 420px;">
    <?php
    if(isset($_SESSION['status'])){
    ?>
    <div class="alert alert-success">
        <?= $_SESSION['status']; ?>
    </div>
    <?php
    unset($_SESSION['status']); }
    ?>
    <form action="logincode.php" method="POST">
      <h1>Login</h1>
        <div class="form-group">
            <input type="email" placeholder="Email" name="email" class="form-control" autocomplete="off">
        </div>
        <div class="form-group">
            <input type="password" placeholder="Password" name="password" class="form-control">
        </div>
        <div class="form-btn">
            <input type="submit" value="Login" name="login" class="btn btn-primary full-width">
        </div>
      </form>
      <div class="forgot-btn">
    <a href="forgot.php" style="text-decoration: none; float: right; font-size: 14px; color: black;">Forgot password?</a>
    </div>
    <div class="registerr">
                <p style="text-align: center; margin-top: 50px; font-size: 14px;">Don't have an account?  <a href="registration.php" style="text-decoration: none; color:black;">Register</a></p>
    </div>
    <hr>
    <h6 class="text-center">
    Did not receive your Verification Email?
    <a href="resend-email.php" class="d-inline-block" style="color: red; text-decoration: none; margin-top: 5px;">Resend</a>
    </h6>
</div>
</body>
</html>