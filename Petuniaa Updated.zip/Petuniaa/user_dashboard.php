<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: user_dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="./asset-image/icons8-dog-bone-32.png" type="image/x-icon">
  <title>Petunia</title>
  <link rel="stylesheet" href="./user_dashboard.css">
</head>

<body>
  <!-- Navigation Starts -->
  <nav class="navbar">
    <div class="navbar-container">
      <h2 class="Petunia"><a href="user_dashboard.php">Petunia</a></h2>
      <ul>
        <li><a href="user_dashboard.php" id="home-button">Home</a></li>
        <li><a href="user_dashboard.php" id="about-button">About</a></li>
        <li class="dropdown">
          <a href="">Services</a>
          <ul class="dropdown-content">
            <li><a href="" id="">Pet Groom</a></li>
          </ul>
        </li>
        <li><a href="necessities.php">Necessities</a></li>
      </ul>
      <div class="sign-in">
    <button><a href="logout.php">Sign out</a></button>
      </div>
    </div>
  </nav>
  <!-- Navigation End-->
  
  <!-- Hero Starts -->
  <main>
    <section class="hero" id="home-section">
      <div class="hero-container">
        <h1>Welcome to Petunia</h1>
        <a href="./user_dashboard.php"><img class="petunialogo" src="./asset-image/Petunia.svg.svg" alt=""></a>
        <div class="container-button">
          <button><a href="appointment.php">Appoint Now</a></button>
        </div>
      </div>
    </section>
  </main>
  <!-- Hero Ends-->
  
  <!-- About Starts-->
  <section class="about" id="about-section">
    <div class="about-container">
      <h1 class="h2">About Petunia</h1>
      <p class="box">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit debitis assumenda dolorem eius enim libero obcaecati odio, nobis, quis praesentium molestias fugiat? Voluptatem ad cupiditate reiciendis nam accusamus, excepturi fuga.</p>
    </div>
  </section>
  <!-- About Ends -->


  <!-- Footer Starts  -->
  <footer>
    <div class="footer-content">
      <div class="footer-column">
        <h2>Petunia</h2>
      </div>
      <div class="footer-column">
        <h3>Location</h3>
        <ul>
          <li><a href="heropage.html">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Services</a></li>
        </ul>
      </div>
      <div class="footer-column">
        <h3>Contact</h3>
        <p>Email: contact@example.com</p>
        <p>Phone: (123) 456-7890</p>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2023 Petunia. All rights reserved.</p>
    </div>
  </footer>
  <!-- Footer Ends  -->
 
  <!-- Scripts -->
  <script src="main.js"></script>
</body>
</html>